/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   aux_func.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 16:23:36 by pzau              #+#    #+#             */
/*   Updated: 2024/08/08 13:57:33 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	GameStart(void)
{
	ft_printf("\n\n");
	ft_printf("  ***** ***** ***** *****  ***** \n");
	ft_printf("  *       *   *   * *    *   *   \n");
	ft_printf("  *****   *   ***** *****    *   \n");
	ft_printf("      *   *   *   * *   *    *   \n");
	ft_printf("  *****   *   *   * *    *   *   \n\n");
}

void	GameEnd(void)
{
	ft_printf("  ***** *    *  ****  \n");
	ft_printf("  *     **   *  *   * \n");
	ft_printf("  ***** * *  *  *   * \n");
	ft_printf("  *     *  * *  *   * \n");
	ft_printf("  ***** *   **  ****  \n\n");
}

void	YouWin(void)
{
	ft_printf("  *      * ***** *    * \n");
	ft_printf("  *  *   *   *   **   * \n");
	ft_printf("  *  **  *   *   * *  * \n");
	ft_printf("  * *  * *   *   *  * * \n");
	ft_printf("  **    ** ***** *   ** \n\n");
}
void	YouLose(void)
{
	ft_printf("  *     ***** ***** ***** \n");
	ft_printf("  *     *   * *     *     \n");
	ft_printf("  *     *   * ***** ***** \n");
	ft_printf("  *     *   *     * *     \n");
	ft_printf("  ***** ***** ***** ***** \n\n");
}

void	espera_tempo(int segundos)
{
	int contador = 0;
	
	while (contador < segundos)
	{
		int ciclos = 0;
		while (ciclos < 100000) 
		{
			ciclos++;
		}
		contador++;
	}
}

int	my_sleep(void)
{
	int ciclos = 0;
	
	while (ciclos < 10000)
	{
		espera_tempo(5);
		ciclos++;
	}
	return 0;
}

/*mini sleep */
void	mini_sleep_a(int segundos)
{
	int	contador = 0;

	while (contador < segundos)
	{
		int ciclos = 0;
		while (ciclos < 100000)
		{
			ciclos++;
		}
		contador++;
	}
}

void	mini_sleep()
{
	int ciclos = 0;

	while (ciclos < 10000)
	{
		mini_sleep_a(6);
		ciclos++;
	}
}
/* mini sleep */

/*Split funct*/
char *ft_strncpy(char *s1, char *s2, int n)
{
	int i = -1;

	while (++i < n && s2[i])
		s1[i] = s2[i];
	s1[i] = '\0';
	return (s1);
}

char	**ft_split(char *str)
{
	int i = 0;
	int j = 0;
	int k = 0;
	int wc = 0;

	while (str[i])
	{
		while (str[i] && (str[i] == ' ' || str[i] == '\t' || str[i] == '\n'))
			i++;
		if (str[i])
			wc++;
		while (str[i] && (str[i] != ' ' && str[i] != '\t' && str[i] != '\n'))
			i++;
	}

	char **out = (char **)malloc(sizeof(char *) * (wc + 1));
	i = 0;

	while (str[i])
	{
		while (str[i] && (str[i] == ' ' || str[i] == '\t' || str[i] == '\n'))
			i++;
		j = i;
		while (str[i] && (str[i] != ' ' && str[i] != '\t' && str[i] != '\n'))
			i++;
		if (i > j)
		{
			out[k] = (char *)malloc(sizeof(char) * ((i - j) + 1));
			ft_strncpy(out[k++], &str[j], i - j);
		}
	}
	out[k] = NULL;
	return (out);
}
/*Split funct*/
