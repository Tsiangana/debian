/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   move_player.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/05 15:33:52 by pzau              #+#    #+#             */
/*   Updated: 2024/08/09 08:52:51 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

/*Mover o jogador*/
int	key_move_hook(int keycode, t_vars *vars)
{
	int new_x = vars->x_pos;
	int new_y = vars->y_pos;

	if (keycode == 65288)
	{
		//vars->current_screen = 0;
		mlx_destroy_window(vars->mlx, vars->win_level);
                ft_printf("  Regressando a tela dos niveis\n\n");
                levels_page(vars);
		return (0);
	}
	if (keycode == 65307)
	{
		mlx_destroy_window(vars->mlx, vars->win_level);
		exit(0);
	}
	else if (keycode == 119)
		new_y -= 1;
	else if (keycode == 115)
		new_y += 1;
	else if (keycode == 97)
		new_x -= 1;
	else if (keycode == 100)
		new_x += 1;
	ft_printf("  O jogador se moveu\n\n");

	if (new_x >= 0 && new_x < vars->dim.largura && new_y >= 0 & new_y < vars->dim.altura && vars->map[new_y][new_x] != '1')
	{
		if (vars->map[new_y][new_x] == 'C')
		{
			vars->coletaveis--;
			ft_printf("  Comeu um coletavel: %d", vars->coletaveis);
		}
		if (vars->map[new_y][new_x] == 'M')
		{
			mlx_destroy_window(vars->mlx, vars->win_level);
			YouLose();
			exit(0);
		}
		if (vars->map[new_y][new_x] == 'E' && vars->coletaveis == 0)
		{
			mlx_destroy_window(vars->mlx, vars->win_level);
			setup_level_two(vars);
		}
		else if (vars->map[new_y][new_x] == 'E')
		{
			ft_printf("  Ainda existem coletaveis no mapa\n\n");
		}
		else 
		{
			vars->map[vars->y_pos][vars->x_pos] = '0';
			vars->x_pos = new_x;
			vars->y_pos = new_y;
			vars->map[vars->y_pos][vars->x_pos] = 'P';
			render_map(vars, vars->map, vars->dim);
		}
	}
	return (0);
}

int     key_move_hook_one(int keycode, t_vars *vars)
{
        int new_x = vars->x_pos;
        int new_y = vars->y_pos;

        if (keycode == 65288)
        {
                mlx_destroy_window(vars->mlx, vars->win_level_one);
                ft_printf("  Regressando a tela dos niveis\n\n");
                levels_page(vars);
                return (0);
        }
        if (keycode == 65307)
        {
                mlx_destroy_window(vars->mlx, vars->win_level_one);
                exit(0);
        }
        else if (keycode == 119)
                new_y -= 1;
        else if (keycode == 115)
                new_y += 1;
        else if (keycode == 97)
                new_x -= 1;
        else if (keycode == 100)
                new_x += 1;
	ft_printf("  O jogador se moveu\n\n");

        if (new_x >= 0 && new_x < vars->dim.largura && new_y >= 0 & new_y < vars->dim.altura && vars->map[new_y][new_x] != '1')
	{
		if (vars->map[new_y][new_x] == 'C')
                {
                        vars->coletaveis--;
			ft_printf("  Contaveis 2: %d", vars->coletaveis);
                }
		if (vars->map[new_y][new_x] == 'M')
                {
                        mlx_destroy_window(vars->mlx, vars->win_level_one);
                        YouLose();
                        exit(0);
                }
                if (vars->map[new_y][new_x] == 'E' && vars->coletaveis == 0)
                {
                        mlx_destroy_window(vars->mlx, vars->win_level_one);
                        setup_level_three(vars);
                }
                else if (vars->map[new_y][new_x] == 'E')
                {
                        ft_printf("  Ainda existem coletaveis no mapa\n\n");
                }
		else
		{
                	vars->map[vars->y_pos][vars->x_pos] = '0';
                	vars->x_pos = new_x;
                	vars->y_pos = new_y;
                	vars->map[vars->y_pos][vars->x_pos] = 'P';
                	render_map_one(vars, vars->map, vars->dim);
        	}
	}
        return (0);
}

int     key_move_hook_two(int keycode, t_vars *vars)
{
        int new_x = vars->x_pos;
        int new_y = vars->y_pos;

        if (keycode == 65288)
        {
                mlx_destroy_window(vars->mlx, vars->win_level_two);
                ft_printf("  Regressando a tela dos niveis\n\n");
                levels_page(vars);
                return (0);
        }
        if (keycode == 65307)
        {
                mlx_destroy_window(vars->mlx, vars->win_level_two);
                exit(0);
        }
        else if (keycode == 119)
                new_y -= 1;
        else if (keycode == 115)
                new_y += 1;
        else if (keycode == 97)
                new_x -= 1;
        else if (keycode == 100)
                new_x += 1;
	ft_printf("  O jogador se moveu\n\n");
        if (new_x >= 0 && new_x < vars->dim.largura && new_y >= 0 & new_y < vars->dim.altura && vars->map[new_y][new_x] != '1')
	{
		if (vars->map[new_y][new_x] == 'C')
                {
                        vars->coletaveis--;
			ft_printf("  coletaveis 3: %d", vars->coletaveis);
                }
		if (vars->map[new_y][new_x] == 'M')
                {
                        mlx_destroy_window(vars->mlx, vars->win_level_two);
                        YouLose();
                        exit(0);
                }
                if (vars->map[new_y][new_x] == 'E' && vars->coletaveis == 0)
                {
                        mlx_destroy_window(vars->mlx, vars->win_level_two);
			YouWin();
                        exit(0);
                }
                else if (vars->map[new_y][new_x] == 'E')
                {
                        ft_printf("  Ainda existem coletaveis no mapa\n\n");
                }
		else
		{
                	vars->map[vars->y_pos][vars->x_pos] = '0';
                	vars->x_pos = new_x;
                	vars->y_pos = new_y;
                	vars->map[vars->y_pos][vars->x_pos] = 'P';
                	render_map_two(vars, vars->map, vars->dim);
        	}
	}
        return (0);
}


/*Mover o jogador*/

/*iniciando posicao do jogador*/
void	init_player_position(t_vars *vars)
{
	int y = 0;
	int x;

	vars->coletaveis = 0;

	while (y < vars->dim.altura)
	{
		x = 0;
		while (x < vars->dim.largura)
		{
			if (vars->map[y][x] == 'P')
			{
				vars->x_pos = x;
				vars->y_pos = y;
				return ;
			}
			else if (vars->map[y][x] == 'C')
				vars->coletaveis++;
			x++;
		}
		y++;
	}
}
/*Iniciando posicao do jogador*/
