/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_map.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/29 09:08:41 by pzau              #+#    #+#             */
/*   Updated: 2024/07/29 15:14:51 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	print_map(const char *filename)
{
	int fd = open(filename, O_RDONLY);
	if (fd < 0)
	{
		ft_printf("  Erro ao abrir o arquivo\n\n");
		exit(EXIT_FAILURE);
	}

	char buffer[1024];
	size_t bytes_read;

	while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0)
	{
		buffer[bytes_read] = '\0';
		ft_printf("%s  \n", buffer);
	}

	if (bytes_read < 0)
	{
		ft_printf("Erro ao ler o arquivo");
		close(fd);
		exit(EXIT_FAILURE);
	}
	close(fd);
}

/*Numero de linhas e colunas*/
void	disp_file(int fd)
{
	t_vars vars;
	char 	buffer;
	int	flag = 0;
	int	w = 0;
	int	h = 0;

	while (read(fd, &buffer, 1) != 0)
	{
		if (buffer != '\n')
		{
			if (!flag)
				w++;
		}
		if (buffer == '\n')
		{
			flag = 1;
			h++;
		}
	}
	ft_printf("  altura: %d", h);
	ft_printf("  largura: %d\n\n", w);
	vars.w_h_one = h;
	vars.w_w_one = w;
	ft_printf("  testar de novo: %d  ", vars.w_h_one);
	ft_printf("  testar de nov0: %d\n\n", vars.w_w_one);
}

void	dimention(char *fdf)
{
	int	fd;

	fd = open(fdf, O_RDONLY);
	if (fd == -1)
	{
		ft_printf("  Erro ao abrir arquivo\n\n");
	}
	disp_file(fd);
	close(fd);
}
/*Numero de linhas e colunas*/
