/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 12:01:34 by pzau              #+#    #+#             */
/*   Updated: 2024/07/27 08:57:34 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

int	main(void)
{
	t_vars	vars;

	vars.mlx = mlx_init();
	//vars.win = mlx_new_window(vars.mlx, 950, 500, "so_long");

	vars.page = 2;

        if (vars.page == 1)
        {
                vars.win = mlx_new_window(vars.mlx, 900, 519, "so_long");

                init_image(&vars);
                draw_small_image(&vars);

                //capturar eeventos do mouse
                mlx_mouse_hook(vars.win, iniciar, &vars);
        }
        if (vars.page == 2)
        {
                vars.win= mlx_new_window(vars.mlx, 950, 500, "so_long");
                back_image(vars.mlx);
                mlx_put_image_to_window(vars.mlx, vars.win, vars.img, 0, 0);
        }


	/*Fechar janela*/
	mlx_hook(vars.win, 17, 0, close_new_window, &vars);
	mlx_key_hook(vars.win, key_esc, &vars);
	/*Fechar janela*/

	GameStart();
	mlx_loop(vars.mlx);
	return (0);
}
