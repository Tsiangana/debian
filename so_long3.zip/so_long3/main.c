/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 12:01:34 by pzau              #+#    #+#             */
/*   Updated: 2024/07/29 15:29:13 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

int	main(void)
{
	t_vars	vars;

	vars.mlx = mlx_init();
	vars.win = mlx_new_window(vars.mlx, 900, 519, "so_long");
	init_image(&vars);
	draw_small_image(&vars);
	
	//capturar eventos do mouse
	mlx_mouse_hook(vars.win, iniciar, &vars);

	mlx_hook(vars.win, 17, 0, close_new_window, &vars);
	mlx_key_hook(vars.win, key_esc, &vars);

	GameStart();
	mlx_loop(vars.mlx);
	return (0);
}
