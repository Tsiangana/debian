/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   aux_func.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 16:23:36 by pzau              #+#    #+#             */
/*   Updated: 2024/07/29 08:01:16 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	GameStart(void)
{
	ft_printf("\n\n");
	ft_printf("  ***** ***** ***** *****  ***** \n");
	ft_printf("  *       *   *   * *    *   *   \n");
	ft_printf("  *****   *   ***** *****    *   \n");
	ft_printf("      *   *   *   * *   *    *   \n");
	ft_printf("  *****   *   *   * *    *   *   \n\n");
}

void	GameEnd(void)
{
	ft_printf("  ***** *    *  ****  \n");
	ft_printf("  *     **   *  *   * \n");
	ft_printf("  ***** * *  *  *   * \n");
	ft_printf("  *     *  * *  *   * \n");
	ft_printf("  ***** *   **  ****  \n\n");
}

void	espera_tempo(int segundos)
{
	int contador = 0;
	
	while (contador < segundos)
	{
		int ciclos = 0;
		while (ciclos < 100000) 
		{
			ciclos++;
		}
		contador++;
	}
}

int	my_sleep(void)
{
	int ciclos = 0;
	
	while (ciclos < 10000)
	{
		espera_tempo(30);
		ciclos++;
	}
	return 0;
}

/*mini sleep */
void	mini_sleep_a(int segundos)
{
	int	contador = 0;

	while (contador < segundos)
	{
		int ciclos = 0;
		while (ciclos < 100000)
		{
			ciclos++;
		}
		contador++;
	}
}

void	mini_sleep()
{
	int ciclos = 0;

	while (ciclos < 10000)
	{
		mini_sleep_a(6);
		ciclos++;
	}
}
/* mini sleep */
