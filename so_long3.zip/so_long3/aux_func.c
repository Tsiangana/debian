/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   aux_func.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 16:23:36 by pzau              #+#    #+#             */
/*   Updated: 2024/07/28 18:55:51 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	GameStart(void)
{
	ft_printf("\n\n");
	ft_printf("  ***** ***** ***** *****  ***** \n");
	ft_printf("  *       *   *   * *    *   *   \n");
	ft_printf("  *****   *   ***** *****    *   \n");
	ft_printf("      *   *   *   * *   *    *   \n");
	ft_printf("  *****   *   *   * *    *   *   \n\n");
}

void	GameEnd(void)
{
	ft_printf("  ***** *    *  ****  \n");
	ft_printf("  *     **   *  *   * \n");
	ft_printf("  ***** * *  *  *   * \n");
	ft_printf("  *     *  * *  *   * \n");
	ft_printf("  ***** *   **  ****  \n\n");
}

void	espera_tempo(int segundos)
{
	int contador = 0;
	
	while (contador < segundos)
	{
		int ciclos = 0;
		while (ciclos < 100000) 
		{
			ciclos++;
		}
		contador++;
	}
}

int	my_sleep(void)
{
	int ciclos = 0;
	
	while (ciclos < 100000)
	{
		espera_tempo(6);
		ciclos++;
	}
	return 0;
}
