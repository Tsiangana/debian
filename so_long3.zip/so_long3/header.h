/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 11:59:12 by pzau              #+#    #+#             */
/*   Updated: 2024/07/31 14:55:01 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef	HEADER_H
# define HEADER_H
# include "minilibx/mlx.h"
# include "my_printf/ft_printf.h"
# include <fcntl.h>
# include <stdio.h>
# include <stdlib.h>

#define PIX 30

typedef struct  s_vars
{
        void    *mlx;
        void    *win;
	void	*img;
	void	*img_w;
	void	*img_level;
	void	*start_img;
	void	*small_img;
	void	*bg_img;
	void	*win_level;
	void	*win_level_one;
	void	*win_level_two;
	void	*win_w;
	void	*win_levels;
	int	img_width;
	int	img_height;
	int	img_width_w;
	int	img_height_w;
	int	img_width_level;
	int	img_height_level;
	int	bg_width;
	int	bg_height;
	int	small_width;
	int	small_height;
	int	x_pos;
	int	y_pos;
	int	w_h_one;
	int	w_w_one;
}		t_vars;

typedef struct	s_vals
{
	void	*level_one;
	void	*level_two;
	void	*level_three;
	int	level_one_width;
	int	level_one_height;
	int	level_one_x;
	int	level_one_y;
	int	level_two_x;
	int	level_two_y;
	int	level_three_x;
	int	level_three_y;
	int	pin_level;
}		t_vals;

int     close_new_window(void *param);
int     key_esc(int keycode, void *param);
void    GameStart(void);
void    GameEnd(void);
int	back_image();
int     init_image(t_vars *vars);
void	draw_small_image(t_vars *vars);
int	iniciar(int button, int x, int y, t_vars *vars);
void    setup_level_window(t_vars *vars);
void    destroy_main_window(t_vars *vars);
int     close_level_one(void *param);
void    espera_tempo(int segundos);
void    waiting_page(t_vars *vars);
void    destroy_waiting(t_vars *vars);
int     back_image_w(t_vars *vars);
int     my_sleep();
void    mini_sleep_a(int segundos);
void    mini_sleep();
void    center_window(t_vars *vars, int window_width, int window_height);
void    print_map(const char *filename);
void    disp_file(int fd);
void    dimention(char *fdf);
void    levels_page(t_vars *vars);
int	back_image_levels(t_vars *vars);
int	close_levels(void *param);
void    buttons_start(t_vars *vars, t_vals *vals);
int     mouse_click_levels(int button, int x, int y, void *param);
void    destroy_level_page(t_vars *vars);
void    setup_level_three(t_vars *vars);
void    setup_level_two(t_vars *vars);
int     cwlo(void *param);
int     cwto(void *param);

#endif
