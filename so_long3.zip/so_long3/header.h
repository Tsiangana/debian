/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 11:59:12 by pzau              #+#    #+#             */
/*   Updated: 2024/07/27 08:54:55 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef	HEADER_H
# define HEADER_H
# include "minilibx/mlx.h"
# include "my_printf/ft_printf.h"

typedef struct  s_vars
{
        void    *mlx;
        void    *win;
	void	*img;
	void	*start_img;
	void	*small_img;
	void	*bg_img;
	int	img_width;
	int	img_height;
	int	bg_width;
	int	bg_height;
	int	small_width;
	int	small_height;
	int	page;
	int	x_pos;
	int	y_pos;
}               t_vars;

int     close_new_window(void *param);
int     key_esc(int keycode, void *param);
void    GameStart(void);
void    GameEnd(void);
int	back_image();
int     init_image(t_vars *vars);
void	draw_small_image(t_vars *vars);
int	iniciar(int button, int x, int y, t_vars *vars);

#endif
