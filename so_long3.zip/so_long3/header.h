/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 11:59:12 by pzau              #+#    #+#             */
/*   Updated: 2024/07/29 15:11:37 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef	HEADER_H
# define HEADER_H
# include "minilibx/mlx.h"
# include "my_printf/ft_printf.h"
# include <fcntl.h>
# include <stdio.h>
# include <stdlib.h>

#define PIX 30

typedef struct  s_vars
{
        void    *mlx;
        void    *win;
	void	*img;
	void	*img_w;
	void	*start_img;
	void	*small_img;
	void	*bg_img;
	void	*win_level;
	void	*win_w;
	int	img_width;
	int	img_height;
	int	img_width_w;
	int	img_height_w;
	int	bg_width;
	int	bg_height;
	int	small_width;
	int	small_height;
	int	x_pos;
	int	y_pos;
	int	w_h_one;
	int	w_w_one;
}               t_vars;

int     close_new_window(void *param);
int     key_esc(int keycode, void *param);
void    GameStart(void);
void    GameEnd(void);
int	back_image();
int     init_image(t_vars *vars);
void	draw_small_image(t_vars *vars);
int	iniciar(int button, int x, int y, t_vars *vars);
void    setup_level_window(t_vars *vars);
void    destroy_main_window(t_vars *vars);
int     close_level_one(void *param);
void    espera_tempo(int segundos);
void    waiting_page(t_vars *vars);
void    destroy_waiting(t_vars *vars);
int     back_image_w(t_vars *vars);
int     my_sleep();
void    mini_sleep_a(int segundos);
void    mini_sleep();
void    center_window(t_vars *vars, int window_width, int window_height);
void    print_map(const char *filename);
void    disp_file(int fd);
void    dimention(char *fdf);


#endif
