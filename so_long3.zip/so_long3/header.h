/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 11:59:12 by pzau              #+#    #+#             */
/*   Updated: 2024/07/28 19:53:48 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef	HEADER_H
# define HEADER_H
# include "minilibx/mlx.h"
# include "my_printf/ft_printf.h"

typedef struct  s_vars
{
        void    *mlx;
        void    *win;
	void	*img;
	void	*wait_img;
	void	*start_img;
	void	*small_img;
	void	*bg_img;
	void	*win_level;
	void	*waiting_page;
	int	img_width;
	int	img_height;
	int	bg_width;
	int	wait_img_h;
	int	wait_img_w;
	int	bg_height;
	int	small_width;
	int	small_height;
	int	x_pos;
	int	y_pos;
}               t_vars;

int     close_new_window(void *param);
int     key_esc(int keycode, void *param);
void    GameStart(void);
void    GameEnd(void);
int	back_image();
int     init_image(t_vars *vars);
void	draw_small_image(t_vars *vars);
int	iniciar(int button, int x, int y, t_vars *vars);
void    setup_level_window(t_vars *vars);
void    destroy_main_window(t_vars *vars);
int     close_level_one(void *param);
void    espera_tempo(int segundos);
int     my_sleep();
void    waiting_page(t_vars *vars);
void    destroy_waiting(t_vars *vars);
int     wait_img_back(t_vars *vars);

#endif
