/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   startGame.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 00:49:13 by pzau              #+#    #+#             */
/*   Updated: 2024/07/29 15:33:13 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

/*Destruir tela anterior*/
void	destroy_main_window(t_vars *vars)
{
	mlx_destroy_window(vars->mlx, vars->win);
	vars->win = NULL;
}

void	destroy_waiting(t_vars *vars)
{
	mlx_destroy_window(vars->mlx, vars->win_w);
	vars->win = NULL;
}
/*Destruir tela anteriror*/

/*tela inicial*/
void	setup_level_window(t_vars *vars)
{
	vars->win_level = mlx_new_window(vars->mlx, 900, 500, "Nivel 1");
	mlx_hook(vars->win_level, 17, 0, close_level_one, vars);
	back_image(vars);
	mlx_put_image_to_window(vars->mlx, vars->win_level, vars->img, 0, 0);

	print_map("game_assets/mapa/mapa2.ber");
	dimention("game_assets/mapa/mapa2.ber");
}
/*tela inicial*/


/*tela de espera*/
void	waiting_page(t_vars *vars)
{
	vars->win_w = mlx_new_window(vars->mlx, 400, 300, "Waiting...");
	back_image_w(vars);
	mlx_put_image_to_window(vars->mlx, vars->win_w, vars->img_w, 0, 0);
}
/*tela de espera*/
