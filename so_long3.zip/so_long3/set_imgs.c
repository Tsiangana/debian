/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   set_imgs.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/28 20:15:44 by pzau              #+#    #+#             */
/*   Updated: 2024/07/29 07:59:37 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

/*Carregar imagem*/
int     init_image(t_vars *vars)
{
        vars->bg_img = mlx_xpm_file_to_image(vars->mlx, "game_assets/intro/50px/intro.xpm", &(vars->bg_width), &(vars->bg_height));
        if (!vars->bg_img)
        {
                ft_printf("Erro ao carregar imagem");
                exit(1);
        }
        return (0);
}

void    draw_small_image(t_vars *vars)
{
        vars->small_img = mlx_xpm_file_to_image(vars->mlx, "game_assets/buttons/start/start.xpm", &(vars->small_width), &(vars->small_height));
        if (!vars->small_img)
        {
                ft_printf("Erro ao carregar imagem do botao start");
                exit(1);
        }
        vars->x_pos = (vars->bg_width - vars->small_width) / 2;
        vars->y_pos = (vars->bg_height - vars->small_height) / 2;

        mlx_put_image_to_window(vars->mlx, vars->win, vars->bg_img, 0, 0);
        mlx_put_image_to_window(vars->mlx, vars->win, vars->small_img, vars->x_pos, vars->y_pos);
}

int     back_image(t_vars *vars)
{
        vars->img = mlx_xpm_file_to_image(vars->mlx, "game_assets/background/50px/xpm/level1.xpm", &(vars->img_width), &(vars->img_height));
        if (!vars->img)
        {
                ft_printf("Erro ao carregar imagem");
                exit(1);
        }
        return (0);
}

int     back_image_w(t_vars *vars)
{
	vars->img_w = mlx_xpm_file_to_image(vars->mlx, "game_assets/waiting_page/level1.xpm", &(vars->img_width_w), &(vars->img_height_w));
	if (!vars->img_w)
	{
		ft_printf("Erro ao carregar imagem2");
		exit(1);
	}
	return (0);
}
/*Carregar imagem*/

