/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hook.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 15:48:15 by pzau              #+#    #+#             */
/*   Updated: 2024/07/29 07:54:17 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

/*fechar janela*/
int	close_new_window(void *param)
{
	t_vars	*vars = (t_vars *)param;

	mlx_destroy_window(vars->mlx, vars->win);
	GameEnd();
	exit(0);
}

int	close_level_one(void *param)
{
	t_vars	*vars = (t_vars *)param;

	mlx_destroy_window(vars->mlx, vars->win_level);
	GameEnd();
	exit(0);
}

int	key_esc(int keycode, void *param)
{
	t_vars *vars = (t_vars *)param;

	if (keycode == 65307)
	{
		mlx_destroy_window(vars->mlx, vars->win);
		GameEnd();
		exit(0);
	}
	return (0);
}
/*fechar janela*/

/*iniciar jogo pelo botao*/
int	iniciar(int button, int x, int y, t_vars *vars)
{
	if (button == 1)
	{
		if (x >= vars->x_pos && x <= vars->x_pos + vars->small_width && y >= vars->y_pos && y <= vars->y_pos + vars->small_height)
		{
			ft_printf("  Iniciar nivel 1\n\n");
			destroy_main_window(vars);
			waiting_page(vars);
			back_image_w(vars);
			ft_printf("  Tela de espera para o nivel 1\n\n");
			my_sleep();
			destroy_waiting(vars);
			ft_printf("  nivel 1 iniciado \n\n");
			setup_level_window(vars);
		}
	}
	return (0);
}
/*iniciar jogo pelo botao*/
