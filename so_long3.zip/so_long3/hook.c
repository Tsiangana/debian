/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hook.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 15:48:15 by pzau              #+#    #+#             */
/*   Updated: 2024/07/27 08:55:35 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

/*fechar janela*/
int	close_new_window(void *param)
{
	t_vars	*vars = (t_vars *)param;

	mlx_destroy_window(vars->mlx, vars->win);
	GameEnd();
	exit(0);
}

int	key_esc(int keycode, void *param)
{
	t_vars *vars = (t_vars *)param;

	if (keycode == 65307)
	{
		mlx_destroy_window(vars->mlx, vars->win);
		GameEnd();
		exit(0);
	}
	return (0);
}
/*fechar janela*/

/*Carregar imagem*/
int	back_image(t_vars vars)
{
	vars.img = mlx_xpm_file_to_image(vars.mlx, "game_assets/background/50px/xpm/level1.xpm", &(vars.img_width), &(vars.img_height));
	if (!vars.img)
	{
		ft_printf("Erro ao carregar imagem");
		exit(1);
	}
	return (0);
}
/*Carregar imagem*/

/*iniciar jogo pelo botao*/
int	iniciar(int button, int x, int y, t_vars *vars)
{
	if (button == 1)
	{
		if (x >= vars->x_pos && x <= vars->x_pos + vars->small_width && y >= vars->y_pos && y <= vars->y_pos + vars->small_height)
		{
			ft_printf("  Iniciar nivel 1\n\n");
			vars->page = 2;
		}
	}
	return (0);
}
/*iniciar jogo pelo botao*/
