/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hook.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 15:48:15 by pzau              #+#    #+#             */
/*   Updated: 2024/07/28 19:58:10 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

/*fechar janela*/
int	close_new_window(void *param)
{
	t_vars	*vars = (t_vars *)param;

	mlx_destroy_window(vars->mlx, vars->win);
	GameEnd();
	exit(0);
}

int	close_level_one(void *param)
{
	t_vars	*vars = (t_vars *)param;

	mlx_destroy_window(vars->mlx, vars->win_level);
	GameEnd();
	exit(0);
}

int	key_esc(int keycode, void *param)
{
	t_vars *vars = (t_vars *)param;

	if (keycode == 65307)
	{
		mlx_destroy_window(vars->mlx, vars->win);
		GameEnd();
		exit(0);
	}
	return (0);
}
/*fechar janela*/

/*Carregar imagem*/
int	back_image(t_vars *vars)
{
	vars->img = mlx_xpm_file_to_image(vars->mlx, "game_assets/background/50px/xpm/level1.xpm", &(vars->img_width), &(vars->img_height));
	if (!vars->img)
	{
		ft_printf("Erro ao carregar imagem");
		exit(1);
	}
	return (0);
}

int	wait_img_back(t_vars *vars)
{
	vars->wait_img = mlx_xpm_file_to_image(vars->mlx, "game_assets/waiting_page/level1.xpm", &(vars->wait_img_w), &(vars->wait_img_h));
	if (!vars->wait_img)
	{
		ft_printf("Erro ao carregar imagem");
		exit(1);
	}
	return (0);
}
/*Carregar imagem*/

/*iniciar jogo pelo botao*/
int	iniciar(int button, int x, int y, t_vars *vars)
{
	if (button == 1)
	{
		if (x >= vars->x_pos && x <= vars->x_pos + vars->small_width && y >= vars->y_pos && y <= vars->y_pos + vars->small_height)
		{
			ft_printf("  Iniciar nivel 1\n\n");
			destroy_main_window(vars);
			waiting_page(vars);
			ft_printf("  Tela de espera para o nivel 1\n");
			my_sleep();
			destroy_waiting(vars);
			ft_printf("  nivel 1 iniciado \n");
			setup_level_window(vars);
		}
	}
	return (0);
}
/*iniciar jogo pelo botao*/
