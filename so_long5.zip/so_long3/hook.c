/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hook.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 15:48:15 by pzau              #+#    #+#             */
/*   Updated: 2024/08/01 06:44:45 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

/*fechar janela*/
int	close_new_window(void *param)
{
	t_vars	*vars = (t_vars *)param;

	mlx_destroy_window(vars->mlx, vars->win);
	GameEnd();
	exit(0);
}

int	close_levels(void *param)
{
	t_vars	*vars = (t_vars *)param;

	mlx_destroy_window(vars->mlx, vars->win_levels);
	GameEnd();
	exit(0);
}

int	close_level_one(void *param)
{
	t_vars	*vars = (t_vars *)param;

	mlx_destroy_window(vars->mlx, vars->win_level);
	GameEnd();
	exit(0);
}

int	cwlo(void *param)
{
	t_vars *vars = (t_vars *)param;

	mlx_destroy_window(vars->mlx, vars->win_level_one);
	GameEnd();
	exit(0);
}

int	cwto(void *param)
{
	t_vars *vars  = (t_vars*)param;

	mlx_destroy_window(vars->mlx, vars->win_level_two);
	GameEnd();
	exit(0);
}

int	key_esc(int keycode, void *param)
{
	t_vars *vars = (t_vars *)param;

	if (keycode == 65307)
	{
		mlx_destroy_window(vars->mlx, vars->win);
		GameEnd();
		exit(0);
	}
	return (0);  GameEnd();

}
int	key_back_one(int keycode, void *param)
{
	t_vars *vars = (t_vars *)param;

	if (keycode == 65288)
	{
		mlx_destroy_window(vars->mlx, vars->win_level);
		ft_printf("  Regressando a tela dos niveis\n\n");
		levels_page(vars);
	}
}

int     key_back_two(int keycode, void *param)
{
        t_vars *vars = (t_vars *)param;

        if (keycode == 65288)
        {
                mlx_destroy_window(vars->mlx, vars->win_level_one);
                ft_printf("  Regressando a tela dos niveis\n\n");
                levels_page(vars);
        }
}

int     key_back_three(int keycode, void *param)
{
        t_vars *vars = (t_vars *)param;

        if (keycode == 65288)
        {
                mlx_destroy_window(vars->mlx, vars->win_level_two);
                ft_printf("  Regressando a tela dos niveis\n\n");
                levels_page(vars);
        }
}

/*fechar janela*/

/*iniciar jogo pelo botao*/
int	iniciar(int button, int x, int y, t_vars *vars)
{
	if (button == 1)
	{
		if (x >= vars->x_pos && x <= vars->x_pos + vars->small_width && y >= vars->y_pos && y <= vars->y_pos + vars->small_height)
		{
			ft_printf("  Selecione seu nivel! \n\n");
			destroy_main_window(vars);
			levels_page(vars); 
		}
	}
	return (0);
}
/*iniciar jogo pelo botao*/

/*botao dos niveis*/
int	mouse_click_levels(int buttons, int x, int y, void *param)
{
	t_vars *vars = (t_vars *)param;
	t_vals vals;

	if (buttons == 1)
	{
		if (x >= 205 && x <= 353 && y >= 223 && y <= 280)
		{
			ft_printf("  Saindo da tela de niveis\n\n");
			destroy_level_page(vars);
			ft_printf("  Entrando no nivel 1\n\n");
			waiting_page(vars);
                        back_image_w(vars);
                        ft_printf("  Tela de espera para o nivel 1\n\n");
                        my_sleep();
                        destroy_waiting(vars);
                        ft_printf("  nivel 1 iniciado\n\n");
                        setup_level_window(vars);
		}
		else if (x >= 380 && x <= 521 && y <= 256 && y <= 280)
		{
			ft_printf("  Saindo da tela de niveis\n\n");
			destroy_level_page(vars);
			ft_printf("  Entrando no nivel 2\n\n");
			waiting_page(vars);
			back_image_w(vars);
			ft_printf("  Tela de espera para o nivel 2 \n\n");
			my_sleep();
			destroy_waiting(vars);
			ft_printf("  Nivel 2 iniciado\n\n");
			setup_level_two(vars);
		}
		else if (x >= 549 && x <= 692 && y >= 229 && y <= 279)
		{
			ft_printf("  Saindo da tela de niveis\n\n");
			destroy_level_page(vars);
			ft_printf("  Entrando no nivel 2\n\n");
			waiting_page(vars);
			back_image_w(vars);
			ft_printf("  Tela de espera para o nivel 3\n\n");
			my_sleep();
			destroy_waiting(vars);
			ft_printf("  Nivel 3 iniciado\n\n");
			setup_level_three(vars);

		}
		else
		{
			ft_printf("  Fora dos botoes\n\n");
		}
	}
	return (0);
}
/*botao dos niveis*/
