/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_map.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/29 09:08:41 by pzau              #+#    #+#             */
/*   Updated: 2024/08/03 07:04:25 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

char	**print_map(const char *filename)
{
	int fd = open(filename, O_RDONLY);
	if (fd < 0)
	{
		ft_printf("  Erro ao abrir o arquivo print_map\n\n");
		exit(EXIT_FAILURE);
	}

	char buffer[1024];
	size_t bytes_read;

	while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0)
	{
		buffer[bytes_read] = '\0';
		ft_printf("%s  \n", buffer);
	}

	if (bytes_read < 0)
	{
		ft_printf("Erro ao ler o arquivo");
		close(fd);
		exit(EXIT_FAILURE);
	}
	return (ft_split(buffer));
	close(fd);
}

/*Numero de linhas e colunas*/
void	disp_file(int fd, dimensoes *dim)
{
	char 	buffer;
	int	flag = 0;
	int	w = 0;
	int	h = 0;

	dim->altura = 0;
	dim->largura = 0;

	while (read(fd, &buffer, 1) != 0)
	{
		if (buffer != '\n')
		{
			if (!flag)
				w++;
		}
		if (buffer == '\n')
		{
			flag = 1;
			h++;
		}
	}
	ft_printf("  altura: %d", h);
	ft_printf("  largura: %d\n\n", w);
	dim->altura = h;
	dim->largura = w;
}

void	dimention(char *fdf, dimensoes *dim)
{
	int	fd;

	fd = open(fdf, O_RDONLY);
	if (fd == -1)
	{
		ft_printf("  Erro ao abrir arquivo dimention\n\n");
	}
	disp_file(fd, dim);
	close(fd);
}
/*Numero de linhas e colunas*/
