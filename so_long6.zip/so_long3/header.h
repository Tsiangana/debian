/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 11:59:12 by pzau              #+#    #+#             */
/*   Updated: 2024/08/07 18:13:04 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef	HEADER_H
# define HEADER_H
# include "minilibx/mlx.h"
# include "my_printf/ft_printf.h"
# include <fcntl.h>
# include <stdio.h>
# include <stdlib.h>

#define PIX 50

typedef struct
{
        int     altura;
        int     largura;
}       dimensoes;

typedef struct  s_vars
{
        void    *mlx;
        void    *win;
	void	*img;
	void	*img_w;
	void	*img_level;
	void	*start_img;
	void	*small_img;
	void	*bg_img;
	void	*win_level;
	void	*win_level_one;
	void	*win_level_two;
	void	*win_w;
	void	*win_levels;
	void	*img_0;
	void	*img_p;
	void	*img_c;
	void	*img_e;
	void	*img_wall;
	char	**map;
	int	img_width;
	int	img_height;
	int	img_width_w;
	int	img_height_w;
	int	img_width_level;
	int	img_height_level;
	int	bg_width;
	int	bg_height;
	int	small_width;
	int	small_height;
	int	x_pos;
	int	y_pos;
	int	w_h_one;
	int	w_w_one;
	int	img_width_img;
	int	img_height_img;
	int	coletaveis;
	dimensoes	dim;
}		t_vars;

typedef struct	s_vals
{
	void	*level_one;
	void	*level_two;
	void	*level_three;
	int	level_one_width;
	int	level_one_height;
	int	level_one_x;
	int	level_one_y;
	int	level_two_x;
	int	level_two_y;
	int	level_three_x;
	int	level_three_y;
	int	pin_level;
}		t_vals;

int     close_new_window(void *param);
int     key_esc(int keycode, void *param);
void    GameStart(void);
void    GameEnd(void);
void    YouWin(void);
int	back_image();
int     init_image(t_vars *vars);
void	draw_small_image(t_vars *vars);
int	iniciar(int button, int x, int y, t_vars *vars);
void    setup_level_window(t_vars *vars);
void    destroy_main_window(t_vars *vars);
int     close_level_one(void *param);
void    espera_tempo(int segundos);
void    waiting_page(t_vars *vars);
void    destroy_waiting(t_vars *vars);
int     back_image_w(t_vars *vars);
int     my_sleep();
void    mini_sleep_a(int segundos);
void    mini_sleep();
void    center_window(t_vars *vars, int window_width, int window_height);
char	**print_map(const char *filename);
void    disp_file(int fd, dimensoes *dim);
void    dimention(char *fdf, dimensoes *dim);
void    levels_page(t_vars *vars);
int	back_image_levels(t_vars *vars);
int	close_levels(void *param);
void    buttons_start(t_vars *vars, t_vals *vals);
int     mouse_click_levels(int button, int x, int y, void *param);
void    destroy_level_page(t_vars *vars);
void    setup_level_three(t_vars *vars);
void    setup_level_two(t_vars *vars);
int     cwlo(void *param);
int     cwto(void *param);
int     key_back_one(int keycode, void *param);
int     key_back_two(int keycode, void *param);
int     key_back_three(int keycode, void *param);
void    load_imagens(t_vars *vars);
void    render_map(t_vars *vars, char **map, dimensoes dim);
char	*ft_strncpy(char *s1, char *s2, int n);
char	**ft_split(char *str);
void    render_map_one(t_vars *vars, char **map, dimensoes dim);
void    render_map_two(t_vars *vars, char **map, dimensoes dim);
int     key_move_hook(int keycode, t_vars *vars);
void    init_player_position(t_vars *vars);
int     key_move_hook_one(int keycode, t_vars *vars);
int     key_move_hook_two(int keycode, t_vars *vars);

#endif
