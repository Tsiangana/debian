/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   render_map.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/05 10:26:24 by pzau              #+#    #+#             */
/*   Updated: 2024/08/07 10:20:46 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

/*Desenhar as imagens do mapa na janela*/
void    render_map(t_vars *vars, char **map, dimensoes dim)
{
        int     x;
        int     y = 0;

        while (y < dim.altura)
        {
                x = 0;
                while (x < dim.largura)
                {
                        void *img;
                        char cell = map[y][x];
                        if (cell == '1')
                                img = vars->img_0;
                        else if (cell == 'P')
                                img = vars->img_p;
                        else if (cell == 'C')
                                img = vars->img_c;
                        else if (cell == 'E')
                                img = vars->img_e;
			else if (cell == '0')
				img  = vars->img_wall;
                        else
                        {
                                x++;
                                continue;
                        }
                        mlx_put_image_to_window(vars->mlx, vars->win_level, img, x*PIX, y*PIX);
                        x++;
                }
                y++;
        }
}

void    render_map_one(t_vars *vars, char **map, dimensoes dim)
{
        int     x;
        int     y = 0;

        while (y < dim.altura)
        {
                x = 0;
                while (x < dim.largura)
                {
                        void *img;
                        char cell = map[y][x];
                        if (cell == '1')
                                img = vars->img_0;
                        else if (cell == 'P')
                                img = vars->img_p;
                        else if (cell == 'C')
                                img = vars->img_c;
                        else if (cell == 'E')
                                img = vars->img_e;
			else if (cell == '0')
				img = vars->img_wall;
                        else
                        {
                                x++;
                                continue;
                        }
                        mlx_put_image_to_window(vars->mlx, vars->win_level_one, img, x*PIX, y*PIX);
                        x++;
                }
                y++;
        }
}

void    render_map_two(t_vars *vars, char **map, dimensoes dim)
{
        int     x;
        int     y = 0;

        while (y < dim.altura)
        {
                x = 0;
                while (x < dim.largura)
                {
                        void *img;
                        char cell = map[y][x];
                        if (cell == '1')
                                img = vars->img_0;
                        else if (cell == 'P')
                                img = vars->img_p;
                        else if (cell == 'C')
                                img = vars->img_c;
                        else if (cell == 'E')
                                img = vars->img_e;
			else if (cell == '0')
				img = vars->img_wall;
                        else
                        {
                                x++;
                                continue;
                        }
                        mlx_put_image_to_window(vars->mlx, vars->win_level_two, img, x*PIX, y*PIX);
                        x++;
                }
                y++;
        }
}
/*Desenhar as imagens do mapa na janela*/
