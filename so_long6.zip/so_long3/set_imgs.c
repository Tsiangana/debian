/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   set_imgs.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/28 20:15:44 by pzau              #+#    #+#             */
/*   Updated: 2024/08/06 18:16:43 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

/*Carregar imagem*/
int     init_image(t_vars *vars)
{
        vars->bg_img = mlx_xpm_file_to_image(vars->mlx, "game_assets/intro/50px/intro.xpm", &(vars->bg_width), &(vars->bg_height));
        if (!vars->bg_img)
        {
                ft_printf("Erro ao carregar imagem");
                exit(1);
        }
        return (0);
}

int     back_image(t_vars *vars)
{
        vars->img = mlx_xpm_file_to_image(vars->mlx, "game_assets/background/50px/xpm/level1.xpm", &(vars->img_width), &(vars->img_height));
        if (!vars->img)
        {
                ft_printf("  Erro ao carregar imagem\n\n");
                exit(1);
        }
        return (0);
}

int     back_image_w(t_vars *vars)
{
	vars->img_w = mlx_xpm_file_to_image(vars->mlx, "game_assets/waiting_page/level1.xpm", &(vars->img_width_w), &(vars->img_height_w));
	if (!vars->img_w)
	{
		ft_printf("  Erro ao carregar imagem2\n\n");
		exit(1);
	}
	return (0);
}

int	back_image_levels(t_vars *vars)
{
	vars->img_level = mlx_xpm_file_to_image(vars->mlx, "game_assets/background/50px/xpm/levels.xpm", &(vars->img_width_level), &(vars->img_height_level));
	if (!vars->img_level)
	{
		ft_printf("  Erro ao carregar imagem dos niveis\n\n");
		exit(1);
	}
	return (0);
}
/*Carregar imagem*/

/*Carregar imagens no mapa*/
void	load_imagens(t_vars *vars)
{
	vars->img_0 = mlx_xpm_file_to_image(vars->mlx, "game_assets/walls/50px/xpm/box.xpm", &vars->img_width_img, &vars->img_height_img);
	vars->img_p = mlx_xpm_file_to_image(vars->mlx, "game_assets/character/50px/xpm/player.xpm", &vars->img_width_img, &vars->img_height_img);
	vars->img_c = mlx_xpm_file_to_image(vars->mlx, "game_assets/jowel/50px/xpm/collect_one.xpm", &vars->img_width_img, &vars->img_height_img);
	vars->img_e = mlx_xpm_file_to_image(vars->mlx, "game_assets/door/50px/xpm/door.xpm", &vars->img_width_img, &vars->img_height_img);
	vars->img_wall = mlx_xpm_file_to_image(vars->mlx, "game_assets/walls/50px/xpm/back_wall.xpm", &vars->img_width_img, &vars->img_height_img);

	if (!vars->img_0 || !vars->img_p || !vars->img_c || !vars->img_e || !vars->img_wall)
	{
		ft_printf("  Erro ao carregar imagens do mapa\n\n");
		exit(1);
	}
}
/*Carregar imagens no mapa*/
