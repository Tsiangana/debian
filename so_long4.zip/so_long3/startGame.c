/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   startGame.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 00:49:13 by pzau              #+#    #+#             */
/*   Updated: 2024/08/02 16:34:52 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

/*Destruir tela anterior*/
void	destroy_main_window(t_vars *vars)
{
	mlx_destroy_window(vars->mlx, vars->win);
	vars->win = NULL;
}

void	destroy_level_page(t_vars *vars)
{
	mlx_destroy_window(vars->mlx, vars->win_levels);
	vars->win_levels = NULL;
}

void	destroy_waiting(t_vars *vars)
{
	mlx_destroy_window(vars->mlx, vars->win_w);
	vars->win = NULL;
}
/*Destruir tela anteriror*/

/*tela inicial*/
void	setup_level_window(t_vars *vars)
{
	dimensoes dim;
	char **map;

	dimention("game_assets/mapa/mapa2.ber", &dim);
	map = load_map("game_assets/mapa/mapa2.ber", &dim);

	vars->win_level = mlx_new_window(vars->mlx, dim.largura*PIX, dim.altura*PIX, "Nivel 1");
	load_imagens(vars);

	mlx_hook(vars->win_level, 17, 0, close_level_one, vars);
	back_image(vars);
	mlx_put_image_to_window(vars->mlx, vars->win_level, vars->img, 0, 0);
	mlx_key_hook(vars->win_level, key_back_one, vars);

	render_map(vars, map, dim);

	print_map("game_assets/mapa/mapa2.ber");
	ft_printf("  Renderizar o mapa:\n\n");
	ft_printf("  Altura: %d Largura: %d\n\n", dim.altura*PIX, dim.largura*PIX);
	//free_map(map, dim);
}

void    setup_level_two(t_vars *vars)
{
	dimensoes dim;
	dimention("game_assets/mapa/mapa1.ber", &dim);
	vars->win_level_one = mlx_new_window(vars->mlx, dim.largura*PIX, dim.altura*PIX, "Nivel 2");

	mlx_hook(vars->win_level_one, 17, 0, cwlo, vars);
	mlx_key_hook(vars->win_level_one, key_back_two, vars);
	//back_image(vars);

	print_map("game_assets/mapa/mapa1.ber");
	ft_printf("  Renderizar o mapa:\n\n");
	ft_printf("  Altura: %d Largura: %d\n\n", dim.altura*PIX, dim.largura*PIX);
}

void	setup_level_three(t_vars *vars)
{
	dimensoes dim;
	dimention("game_assets/mapa/mapa2.ber", &dim);

	vars->win_level_two = mlx_new_window(vars->mlx, dim.largura*PIX, dim.altura*PIX, "Nivel 3");
	mlx_hook(vars->win_level_two, 17, 0, cwto, vars);
	mlx_key_hook(vars->win_level_two, key_back_three, vars);
	//back_image(vars);
	print_map("game_assets/mapa/mapa3.ber");
	ft_printf("  Renderizar o mapa:\n\n");
	ft_printf("  Altura: %d Largura: %d\n\n", dim.altura*PIX, dim.largura*PIX);
}

/*tela inicial*/


/*tela de espera*/
void	waiting_page(t_vars *vars)
{
	vars->win_w = mlx_new_window(vars->mlx, 400, 300, "Waiting...");
	back_image_w(vars);
	mlx_put_image_to_window(vars->mlx, vars->win_w, vars->img_w, 0, 0);
}
/*tela de espera*/

/*Tela de niveis*/
void	levels_page(t_vars *vars)
{
	t_vals vals;
	vars->win_levels = mlx_new_window(vars->mlx, 900, 506, "Select Levels");
	back_image_levels(vars);
	mlx_put_image_to_window(vars->mlx, vars->win_levels, vars->img_level, 0, 0);
	mlx_hook(vars->win_levels, 17, 0, close_levels, vars);

	vals.level_one = mlx_xpm_file_to_image(vars->mlx, "game_assets/buttons/level1.xpm", &vals.level_one_width, &vals.level_one_height);
	vals.level_two = mlx_xpm_file_to_image(vars->mlx, "game_assets/buttons/level2.xpm", &vals.level_one_width, &vals.level_one_height);
	vals.level_three = mlx_xpm_file_to_image(vars->mlx, "game_assets/buttons/level3.xpm", &vals.level_one_width, &vals.level_one_height);

	if (!vals.level_one || !vals.level_two || !vals.level_three)
	{
		ft_printf("  Erro ao abrir imagem dos botoes de niveis\n\n");
		exit(1);
	}
	buttons_start(vars, &vals);
	mlx_mouse_hook(vars->win_levels, mouse_click_levels, vars);
}
/*Tela de niveis*/

/*Desenhar as imagens do mapa na janela*/
void	render_map(t_vars *vars, char **map, dimensoes dim)
{
	int	x;
	int	y;

	while (y < dim.altura)
	{
		x = 0;
		while (x < dim.largura)
		{
			void *img;
			char cell = map[y][x];
			if (cell == '0')
				img = vars->img_0;
			else if (cell == 'P')
				img = vars->img_p;
			else if (cell == 'C')
				img = vars->img_c;
			else if (cell == 'E')
				img = vars->img_c;
			else
			{
				x++;
				continue;
			}
			mlx_put_image_to_window(vars->mlx, vars->win_level, img, x*PIX, y*PIX);
			x++;
		}
		y++;
	}
}
/*Desenhar as imagens do mapa na janela*/
