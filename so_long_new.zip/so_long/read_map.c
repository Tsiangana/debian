/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_map.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 16:58:53 by pzau              #+#    #+#             */
/*   Updated: 2024/08/17 11:23:42 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

char	**print_map(const char *filename)
{
	t_vars	*vars;
	char	buffer[1025];
	int		bytes_read;
	int		fd;
	char	*content = NULL;
	char	*temp = NULL;

	fd = open(filename, O_RDONLY);
	bytes_read = read(fd, buffer, sizeof(buffer));
	if (fd < 0)
		exit(1);
	while (bytes_read > 0)
	{
		buffer[bytes_read] = '\0';
		ft_printf("%s \n", buffer);
		temp = content;
		content = (temp == NULL) ? ft_strdup(buffer) : ft_strcat(temp, buffer);
		if (temp)
			free(temp);
		bytes_read = read(fd, buffer, sizeof(buffer));
	}
	close(fd);
	if (bytes_read < 0 || !content)
	{
		ft_printf("  Erro ao ler arquivo");
		close(fd);
		exit(1);
	}
	char	**map = ft_split(content);
	free(content);
	return (map);
}
