/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   aux.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/16 13:03:05 by pzau              #+#    #+#             */
/*   Updated: 2024/08/17 11:31:15 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

int	delimiter(char c)
{
	return (c == ' ' || c == '\t' || c == '\n');
}

int	count_words(char *s)
{
	int	count = 0;

	while (*s)
	{
		while (*s && delimiter(*s))
			s++;
		if (*s && !delimiter(*s))
		{
			count++;
			while (*s && !delimiter(*s))
				s++;
		}
	}
	return (count);
}

char	**ft_split(char *s)
{
	int	x = 0;
	int	y = 0;
	int	start, words = count_words(s);
	char	**matrix = malloc(sizeof(char *) * (words + 1));

	if (!matrix)
		return (NULL);
	while (*s)
	{
		while (*s && delimiter(*s))
			s++;
		if (*s && !delimiter(*s))
		{
			start = 0;
			while (s[start] && !delimiter(s[start]))
				start++;
			matrix[y] = malloc(sizeof(char) * (start + 1));
			if (!matrix[y])
			{
				free_split(matrix);
				return (NULL);
			}
			x = 0;
			while (x < start)
				matrix[y][x++] = *s++;
			matrix[y][x] = '\0';
			y++;
		}
	}
	matrix[y] = NULL;
	return (matrix);
}

int	ft_strlen(const char *str)
{
	int	length;

	length = 0;
	while (str[length])
		length++;
	return (length);
}

void	free_split(char **matrix)
{
	int	i;

	i = 0;
	if (matrix)
	{
		while (matrix[i])
		{
			free(matrix[i]);
			i++;
		}
		free(matrix);
	}
}

char	*ft_strdup(char *str)
{
	int	i = 0;
	char	*new;

	while (str[i])
		i++;
	new = malloc(sizeof(char) * (i + 1));
	i = 0;
	while (str[i])
	{
		new[i] = str[i];
		i++;
	}
	new[i] = '\0';
	return (new);
}

char	*ft_strcat(char *dest, const char *src)
{
	int i = 0;
	int j = 0;

	while (dest[i] != '\0')
		i++;
	while (src[j] != '\0')
	{
		dest[i] = src[j];
		i++;
		j++;
	}
	dest[i] = '\0';
	return (dest);
}
