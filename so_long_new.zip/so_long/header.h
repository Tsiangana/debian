/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 16:52:13 by pzau              #+#    #+#             */
/*   Updated: 2024/08/17 11:31:22 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HEADER_H
# define HEADER_H
# include <stdio.h>
# include <stdlib.h>
# include <fcntl.h>
# include "minilibx/mlx.h"
# include "my_printf/ft_printf.h"

typedef struct s_vars
{
	void		*mlx;
	void		*win;
	char		**map;
}	t_vars;


void		free_split(char **matrix);
char		**ft_split(char *s);
char		*ft_strdup(char *str);
char		*ft_strcat(char *dest, const char *src);
char		**print_map(const char *filename);
int			delimiter(char c);
int			ft_strlen(const char *str);
int			close_x(void *param);
int			count_words(char *s);

#endif
